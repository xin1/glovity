#include "protocol.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>

namespace telex {

bool parse_frame(const uint8_t* data, size_t len, RawFrame& out) {
    if (len != static_cast<size_t>(FRAME_SIZE)) return false;
    if (data[0] != MAGIC0 || data[1] != MAGIC1) return false;
    if (data[2] != HAND_LEFT && data[2] != HAND_RIGHT) return false;
    if (data[3] != IMU_COUNT) return false;
    if (xor_check(data, FRAME_SIZE - 1) != data[FRAME_SIZE - 1]) return false;

    RawFrame f;
    f.hand_id     = static_cast<int>(data[2]);
    f.bat_percent = static_cast<int>(data[4]);
    f.frame_id    = read_u16_le(data + 5);

    for (int i = 0; i < IMU_COUNT; ++i) {
        const uint8_t* p = data + HEADER_SIZE + i * IMU_RAW_SIZE;
        // raw[0..2] = euler, raw[3..6] = quat(w,x,y,z)
        f.imu[i].w = read_i16_le(p + 6)  * QUAT_SCALE;
        f.imu[i].x = read_i16_le(p + 8)  * QUAT_SCALE;
        f.imu[i].y = read_i16_le(p + 10) * QUAT_SCALE;
        f.imu[i].z = read_i16_le(p + 12) * QUAT_SCALE;
    }

    const uint8_t* wp = data + HEADER_SIZE + WRIST_IMU_INDEX * IMU_RAW_SIZE;
    for (int i = 0; i < 3; ++i)
        f.wrist_euler_deg[i] = read_i16_le(wp + 2 * i) * ANG_SCALE;

    const uint8_t* gp = data + EXTRA_OFFSET;
    for (int i = 0; i < 3; ++i)
        f.wrist_gyro_dps[i] = read_i16_le(gp + 2 * i) * GYRO_SCALE;

    out = f;
    return true;
}

namespace {

void write_i16_le(uint8_t* p, int v) {
    const uint16_t u = static_cast<uint16_t>(static_cast<int16_t>(v));
    p[0] = static_cast<uint8_t>(u & 0xFF);
    p[1] = static_cast<uint8_t>((u >> 8) & 0xFF);
}

int quantize(double v) {
    // 对应 Python: int(max(-32768, min(32767, round(v * 32768.0))))
    double r = std::round(v * 32768.0);
    if (r < -32768.0) r = -32768.0;
    if (r > 32767.0) r = 32767.0;
    return static_cast<int>(r);
}

}  // namespace

std::vector<uint8_t> build_test_frame(int hand_id, uint16_t frame_id,
                                      const QuatWXYZ& quat, uint8_t bat_percent) {
    std::vector<uint8_t> buf(FRAME_SIZE, 0);
    buf[0] = MAGIC0;
    buf[1] = MAGIC1;
    buf[2] = static_cast<uint8_t>(hand_id);
    buf[3] = IMU_COUNT;
    buf[4] = bat_percent;
    buf[5] = static_cast<uint8_t>(frame_id & 0xFF);
    buf[6] = static_cast<uint8_t>((frame_id >> 8) & 0xFF);

    const int qw = quantize(quat.w), qx = quantize(quat.x);
    const int qy = quantize(quat.y), qz = quantize(quat.z);
    for (int i = 0; i < IMU_COUNT; ++i) {
        uint8_t* p = buf.data() + HEADER_SIZE + i * IMU_RAW_SIZE;
        write_i16_le(p + 0, 0);
        write_i16_le(p + 2, 0);
        write_i16_le(p + 4, 0);
        write_i16_le(p + 6, qw);
        write_i16_le(p + 8, qx);
        write_i16_le(p + 10, qy);
        write_i16_le(p + 12, qz);
    }
    for (int i = 0; i < 3; ++i) write_i16_le(buf.data() + EXTRA_OFFSET + 2 * i, 0);
    buf[FRAME_SIZE - 1] = xor_check(buf.data(), FRAME_SIZE - 1);
    return buf;
}

void FrameSync::feed(const uint8_t* data, size_t len) {
    if (len == 0) return;
    buf_.insert(buf_.end(), data, data + len);
}

bool FrameSync::next(RawFrame& out) {
    for (;;) {
        // 找 magic
        size_t idx = std::string::npos;
        if (buf_.size() >= 2) {
            for (size_t i = 0; i + 1 < buf_.size(); ++i) {
                if (buf_[i] == MAGIC0 && buf_[i + 1] == MAGIC1) { idx = i; break; }
            }
        }
        if (idx == std::string::npos) {
            // 无 magic：保留末尾 FRAME_SIZE 字节（可能含半个 magic 与部分帧）
            if (buf_.size() > static_cast<size_t>(FRAME_SIZE))
                buf_.erase(buf_.begin(),
                           buf_.end() - static_cast<std::ptrdiff_t>(FRAME_SIZE));
            return false;
        }
        if (idx > 0) buf_.erase(buf_.begin(), buf_.begin() + static_cast<std::ptrdiff_t>(idx));

        if (buf_.size() < 3) return false;

        if (buf_[2] != HAND_LEFT && buf_[2] != HAND_RIGHT) {
            buf_.erase(buf_.begin());  // 设备号非法，丢 1 字节重扫
            continue;
        }
        if (buf_.size() < static_cast<size_t>(FRAME_SIZE)) return false;

        if (parse_frame(buf_.data(), FRAME_SIZE, out)) {
            buf_.erase(buf_.begin(), buf_.begin() + FRAME_SIZE);
            return true;
        }
        buf_.erase(buf_.begin());  // 校验失败只前进 1 字节
    }
}

}  // namespace telex
