"""Portable esptool command-line entry point; see bundled third-party licenses."""
import esptool

if __name__ == '__main__':
    esptool._main()
